/*
 * Cycle.c
 *
 * Created: 10/3/2022 5:16:10 AM
 * Author : qiriro
 */ 

#include <avr/io.h>
#include<util/delay.h>

int main(void)
{
	DDRB |= (1<<DDB0) |(1<<DDB1) |(1<<DDB2)|(1<<DDB3); 
	int i =0;
    while (1) 
    {
		for (i=0; i<5; i++)
		{
			PORTB =(1<<i);
			_delay_ms(500);
		}
		for (--i; i>0; i--)
		{
			PORTB =(1<<i);
			_delay_ms(200);
		}
    }
}

