
/*
 * Created: 2/26/2021 9:40:46 AM
 * Created: 2/15/2015 2:22:11 PM
 * Processor: ATtiny13
 * Compiler:  AVR/GNU C Compiler
 * Author: Kizito NKURIKIYEYEZU
 * File Version: 0.1
 * Required File: None
 * Description: This code toggle LEDs connected to PORTB
 * Objectives:
 * Pin Assignment:
       - LED connected to PINB0
 */

#define F_CPU 1000000UL
#include <avr/io.h>
#include<util/delay.h>

int main(void) 
{

//Set the PIN of PB0 an output
//NOTE: In AVR MCU, writing a one to the DDR makes the corresponding pin an output
  DDRB |= (1<<DDB0);        
  while (1) 
  {
	// Toggle the 1st bit on PORT B (i.e. PB0)
	PORTB ^= (1<<PB0);  
	_delay_ms(1000);                                      
  } 
   //This line is never reached unless there is a critical problem                                            
  return 0;                           
}
