/*
 * app_tasks.c
 *
 * Created: 11/23/2020 5:03:34 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 
#include <stdbool.h> // For true and false
#include <avr/io.h>
#define F_CPU 16000000UL //XTAL frequency = 16MHz
#include <util/delay.h>
#include <Arduino.h>
#include "Arduino_FreeRTOS.h"
#include "include/app_tasks.h"
#include "include/board.h"
#include "include/util.h"
#include "include/stack_size.h"
#include "include/priorities.h"

void vYellowLedTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	DDRB |= (1<<LED_YELLOW);
	//pinMode(12, OUTPUT);
	// Remember all tasks should run as an infinite loop
	while(true)
	{
		PORTB ^= (1<<LED_YELLOW);
		os_delay_ms(1000);
		
	}
	/*  Tasks must not attempt to return from their implementing
        function or otherwise exit.  In newer FreeRTOS port
        attempting to do so will result in an configASSERT() being
        called if it is defined.  If it is necessary for a task to
        exit then have the task call vTaskDelete( NULL ) to ensure
        its exit is clean. 
	*/
        vTaskDelete( NULL );
}
void vRedLedTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	DDRB |= (1<<LED_RED);
	while(true)
	{
		PORTB ^= (1<<LED_RED);
		os_delay_ms(750);
	}
	 vTaskDelete( NULL );
}
void vGreenLedTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	DDRB |= (1<<LED_GREEN);
	while(true)
	{
		PORTB ^= (1<<LED_GREEN);
		os_delay_ms(500);
	}
	vTaskDelete( NULL );
}
void vBlueLedTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	DDRB |= (1<<LED_BLUE);
	while(true)
	{
		PORTB ^= (1<<LED_BLUE);
		os_delay_ms(250);
	}
	vTaskDelete( NULL );
}
void vStatusTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	DDRB |= (1<<LED_BUILTIN);
	while(true)
	{
		PORTB ^= (1<<LED_BUILTIN);
		
		os_delay_ms(2000);
	}
	vTaskDelete( NULL );
}
void os_init()
{
	// Setup the task to blink the yellow
	xTaskCreate(
	vYellowLedTask,      //  Name of the task
	"yellow led task",        //   a name for debugging purpose
	OS_MINIMUM_STACK_SIZE,  // The stack size the task will use
	NULL,
	OS_PRIORITY_NORMAL,  // Specify the priority of this task
	NULL);
	
	
	// Setup the task to blink red led
	xTaskCreate(
	vRedLedTask,      //  Name of the task
	"red led task",        //   a name for debugging purpose
	OS_MINIMUM_STACK_SIZE,  // The stack size the task will use
	NULL,
	OS_PRIORITY_NORMAL,  // Specify the priority of this task
	NULL);
	
	// Setup the task to blink red led
	xTaskCreate(
	vBlueLedTask,      //  Name of the task
	"blue led task",        //   a name for debugging purpose
	OS_MINIMUM_STACK_SIZE,  // The stack size the task will use
	NULL,
	OS_PRIORITY_NORMAL,  // Specify the priority of this task
	NULL);
	
	
	
	// Setup the task to blink the green led
	xTaskCreate(
	vGreenLedTask,   
	"red led task",       
	OS_MINIMUM_STACK_SIZE, 
	NULL,
	OS_PRIORITY_NORMAL,  
	NULL);
	
	// Setup the task to status led
	xTaskCreate(
	vStatusTask,
	"status task",
	OS_MINIMUM_STACK_SIZE,
	NULL,
	OS_PRIORITY_LOW,
	NULL);

	// Start scheduler.
	vTaskStartScheduler();
	
}
void vApplicationIdleHook(){}
void vApplicationTickHook(){}
void vApplicationAssertHook(){}
void vApplicationMallocFailedHook(){}
void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcTaskName ){}