/*
 * app_tasks.h
 *
 * Created: 11/23/2020 4:25:24 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 


#ifndef APP_TASKS_H_
#define APP_TASKS_H_


// Prototypes for the FreeRTOS hook tasks
void vApplicationIdleHook();
void vApplicationTickHook();
void vApplicationAssertHook();
void vApplicationMallocFailedHook();
void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcTaskName );

// Prototypes of application specific task
void vYellowLedTask(void *pvParameters __attribute__((unused)));
void vBlueLedTask(void *pvParameters __attribute__((unused)) );
void vGreenLedTask(void *pvParameters __attribute__((unused)) );
void vRedLedTask(void *pvParameters __attribute__((unused)));
void vStatusTask(void *pvParameters __attribute__((unused)));


// Task initialization
void os_init();
#endif /* APP_TASKS_H_ */