/*
 * pin_definitions.h
 *
 * Created: 11/23/2020 4:32:51 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 


#ifndef BOARD_H_
#define BOARD_H_
#include "pins_atmega2560.h"

// LED peripherals
#define LED_YELLOW       IO50
#define LED_BLUE         IO51
#define LED_RED          IO52
#define LED_GREEN        IO53
#define LED_BUILTIN      IO13 



#endif /* BOARD_H_ */