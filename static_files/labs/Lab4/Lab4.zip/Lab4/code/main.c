﻿#include <Arduino_FreeRTOS.h>
#include <Arduino.h>
#include "include/app_tasks.h"
void setup() 
{
  os_init();
}

void loop(){}

